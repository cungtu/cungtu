/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
 * nSnake - The classic snake game with ncurses.                              *
 * Copyright (C) 2011  Alexandre Dantas (kure)                                *
 *                                                                            *
 * This file is part of nSnake.                                               *
 *                                                                            *
 * nSnake is free software: you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation, either version 3 of the License, or          *
 * any later version.                                                         *
 *                                                                            *
 * This program is distributed in the hope that it will be useful,            *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.      *
 *                                                                            *
 * homepage: http://sourceforge.net/projects/nsnake/                          *
 *                                                                            *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

/**	@file   main.c
 *	The 'main' function only
 */

/*------------------------------INCLUDES--------------------------------------*/


#include "engine.h"
#include "fruit.h"
#include "nsnake.h"
#include "player.h"


/*--------------------------START--------HERE---------------------------------*/


/**	The main function - contains the main loop of the game.
 *
 *
 *	Note:	I tried to make this function as clear as possible, so anyone
 * 		could understaing the whole game logic starting by here. @n
 *		Have fun with the source code!
 */
 int main (int argc, char* argv[])
{
	NSN_handleArguments (argc, argv);

	ENG_initGameEngine ();

	ENG_displayMainMenu ();

	NSN_initGame ();

	while (1 == 1)
	{
		ENG_handleInputGame ();

		if (snake.is_alive == False)
		{
			NSN_gameOver ();
		}

		PLA_updatePlayer ();

		FRU_updateFruitBonusValue ();
		FRU_checkCollisionFruit ();
		if (fruit.exists == False)
		{
			FRU_createFruit ();
		}

		PLA_checkCollisionSelf ();
		PLA_checkCollisionWall ();

		ENG_drawScreenEngine ();
	}

	ENG_exitGameEngine ();
	NSN_exitGame ();

return 0;
}








//------------------------------------------------------------------------------
//------NOTE------------The-following-comments-are-for-generating-the-document--
//----------------------file---/doc/html/index.html-----------------------------
//----------------------So-these-comments-doesnt-belong-to-the-game-itself.-----
//------------------------------------------------------------------------------

/**	@mainpage	Documentation Main Page
 *
 * 		<h2> Introduction </h2>
 * 		This is the main documentation page of nSnake. <br />
 * 		It was made for programmers and people who want to understand
 * 		the source code. <br />
 * 		<br />
 * 		Here is the folder and file structure: <br />
 *		<br />
 *
 * 		<table align="center" border="1">
 * 		<tr>	<td> General game information </td>
 * 			<td> README file </td>
 * 		</tr>
 * 		<tr>	<td> Installation instructions and information </td>
 * 			<td> INSTALL file </td>
 * 		</tr>
 * 		<tr>	<td> Copyright and warranty info </td>
 * 			<td> COPYING file </td>
 * 		</tr>
 * 		<tr>	<td> Doxygen file for generating this documentation. </td>
 * 			<td> Doxyfile file </td>
 * 		</tr>
 * 		<tr>	<td> Instructions to the 'make' program. </td>
 * 			<td> Makefile file </td>
 * 		</tr>
 * 		<tr>	<td> Work that needs to be done or ideas for future versions. </td>
 * 			<td> TODO file </td>
 * 		</tr>
 * 		<tr>	<td> All of the source code files. </td>
 * 			<td> /src folder </td>
 * 		</tr>
 * 		<tr>	<td> The complete documentation files </td>
 * 			<td> /doc folder </td>
 * 		</tr>
 * 		<tr>	<td> Libraries needed and temporary location of object files </td>
 * 			<td> /lib folder </td>
 * 		</tr>
 * 		<tr>	<td> Location of the main binary generated after compilation </td>
 * 			<td> /bin folder </td>
 * 		</tr>
 *		</table>
 *
 * 		<br />
 * 		<h2> Description </h2>
 * 		One important objective i kept in mind when coding nSnake,
 * 		was to make the source code as simple as it could be. <br />
 * 		I wished too that this code could be a guide to C programming
 * 		and nCurses learning for beginners.
 * 		<br />
 * 		But with time, the game structure got more complicated; i had
 * 		to break large chunks of code into more manageable files; the
 * 		folder structure wasn't as clean as before; the Makefile got
 * 		bigger and bigger... I kinda lost myself around somewhere.
 * 		<br />
 * 		So now i think this source code may be a guide to people who
 * 		are used to programming, but don't know about coding standards,
 * 		modularization, naming rules, and such. <br />
 * 		Then, if you already have a project (or if you are making one)
 * 		i highly recommend you take a time to read these source files
 * 		and consider at least some of the ideas i present. <br />
 * 		For example, the function names. <br /> <br />
 * 		Each group of .c and .h files represent an unique concept.
 * 		<i>Player, Fruit and Scores</i>, together with <i>Main</i> and
 * 		<i>nSnake</i> itself. Each of those has a responsability on the
 * 		game. <br />
 * 		So i renamed each function to this pattern:
 * 			<div align="center">
 * 			<b> MOD_actionProvidedByFunction () </b>
 * 			</div>
 * 		<br />
 *		This way, just by looking at it you know where this function is
 * 		from.
 *
 *		      (TODO continue description)
 */
/*------------------------------END-------------------------------------------*/

