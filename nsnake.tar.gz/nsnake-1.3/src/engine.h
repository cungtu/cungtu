/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
 * nSnake - The classic snake game with ncurses.                              *
 * Copyright (C) 2011  Alexandre Dantas (kure)                                *
 *                                                                            *
 * This file is part of nSnake.                                               *
 *                                                                            *
 * nSnake is free software: you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation, either version 3 of the License, or          *
 * any later version.                                                         *
 *                                                                            *
 * This program is distributed in the hope that it will be useful,            *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.      *
 *                                                                            *
 * homepage: http://sourceforge.net/projects/nsnake/                          *
 *                                                                            *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

/**	@file   engine.h
 *	Declaration of the graphical engine functions, defines and globals
 *
 * 	All functions related to this module begin with 'ENG_'
 *
 */

#ifndef ENGINE_DEFINED

/*------------------------------DEFINES---------------------------------------*/


#define ENGINE_DEFINED


/*------------------------------INCLUDES--------------------------------------*/


#include <ncurses.h>


/*------------------------------GLOBALS---------------------------------------*/


///	The fixed width of the game area
extern int WIDTH;

///	The fixed height of the game area
extern int HEIGHT;


/*------------------------------FUNCTIONS-------------------------------------*/


void ENG_displayMainMenu ();
void ENG_drawBackground ();
void ENG_drawFruit ();
void ENG_drawFruitBonus ();
void ENG_drawGameOver ();
void ENG_drawMainMenu (WINDOW* main_menu);
void ENG_drawPause ();
void ENG_drawPlayer ();
void ENG_drawScore ();
void ENG_drawScreenEngine ();
void ENG_drawWindowBorder ();
void ENG_exitGameEngine ();
void ENG_exitMainMenu (WINDOW* main_menu);
bool ENG_handleInputMainMenu (int* current_option);
void ENG_handleInputGame ();
void ENG_handleInputGameOver ();
void ENG_handleInputPauseMenu ();
void ENG_initGameEngine ();
WINDOW*  ENG_initMainMenu ();


/*------------------------------END-------------------------------------------*/
#endif

