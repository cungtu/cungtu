/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
 * nSnake - The classic snake game with ncurses.                              *
 * Copyright (C) 2011  Alexandre Dantas (kure)                                *
 *                                                                            *
 * This file is part of nSnake.                                               *
 *                                                                            *
 * nSnake is free software: you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation, either version 3 of the License, or          *
 * any later version.                                                         *
 *                                                                            *
 * This program is distributed in the hope that it will be useful,            *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.      *
 *                                                                            *
 * homepage: http://sourceforge.net/projects/nsnake/                          *
 *                                                                            *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

/**     @file   scores.c
 *	Definition of the functions related to scores
 */


/*------------------------------DEFINES---------------------------------------*/


#define SCORES_C

//	We also get a define from the Makefile called SCORES_FILE
//	It indicates the whole path to the scores file.
//	By default, it is /var/games/nsnake/high.scores
//	but it depends on the installation directory set by the user


/*------------------------------INCLUDES--------------------------------------*/


#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "scores.h"
#include "player.h"
#include "nsnake.h"
#include "engine.h"


/*------------------------------GLOBALS---------------------------------------*/


unsigned int HIGH_SCORE_DEFAULT = 500;		///< The Default HighScore

unsigned int HIGH_SCORE_NORMAL;			///< Normal Mode HighScore
unsigned int HIGH_SCORE_TELEPORT;		///< Teleport Mode HighScore


/*------------------------------FUNCTIONS-------------------------------------*/


/**	Simply increases the score by the value sent as the parameter
 */
void SCO_increaseScore (int add)
{
	snake.score += add;

}


/**	Creates/reads from the High Score file
 *
 *	@note	The path to the High Score file is defined via command line. @n
 *		It uses -DSCORES_FILE="path/to/scores/file"
 *
 *	@todo	clean this code. Lots of useless ifs and elses.
 */
void SCO_initHighScore ()
{
	FILE* file;
	file = fopen (SCORES_FILE, "rb");

	if (file == NULL)
	{
		file = fopen (SCORES_FILE, "wb");
		HIGH_SCORE_NORMAL = HIGH_SCORE_DEFAULT;
		HIGH_SCORE_TELEPORT = HIGH_SCORE_DEFAULT;

		if (file != NULL)
		{
			fwrite (&HIGH_SCORE_NORMAL, sizeof (unsigned int), 1, file);
			fwrite (&HIGH_SCORE_TELEPORT, sizeof (unsigned int), 1, file);
		}
	}
	else
	{
		int size;

		size = fread (&HIGH_SCORE_NORMAL, sizeof (unsigned int), 1, file);
		if (size != sizeof (unsigned int))
		{
			NSN_abortGame ("Highscore File I/O error!");
		}

		size = fread (&HIGH_SCORE_TELEPORT, sizeof (unsigned int), 1, file);
		if (size != sizeof (unsigned int))
		{
			NSN_abortGame ("Highscore File I/O error!");
		}
	}

	if (file == NULL)
	{
		//This time it really couldnt open the score file
	}
	else
	{
		fclose (file);
	}
}


/**	Records the player High Score
 */
void SCO_obtainHighScore ()
{
	FILE* file;
	file = fopen (SCORES_FILE, "r+b");

	if (file == NULL)
	{
		file = fopen (SCORES_FILE, "wb");
	}



	if (GAME_MODE == BORDERS_ON)
	{
		HIGH_SCORE_NORMAL = snake.score;
	}
	else if (GAME_MODE == BORDERS_OFF)
	{
		HIGH_SCORE_TELEPORT = snake.score;
	}



	if (file == NULL)
	{
		// TODO silently print this error (to only show at the end)
		//printf ("* Error opening file '~/.nsnake/scores.bin'!\n");
	}
	else
	{
		if (GAME_MODE == BORDERS_ON)
		{
			fwrite (&HIGH_SCORE_NORMAL, sizeof (unsigned int), 1, file);
		}
		else if (GAME_MODE == BORDERS_OFF)
		{
			fseek (file, sizeof (unsigned int), SEEK_SET);
			fwrite (&HIGH_SCORE_TELEPORT, sizeof (unsigned int), 1, file);
		}

		fclose (file);
	}
}


/*------------------------------END-------------------------------------------*/
