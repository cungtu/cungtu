/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
 * nSnake - The classic snake game with ncurses.                              *
 * Copyright (C) 2011  Alexandre Dantas (kure)                                *
 *                                                                            *
 * This file is part of nSnake.                                               *
 *                                                                            *
 * nSnake is free software: you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation, either version 3 of the License, or          *
 * any later version.                                                         *
 *                                                                            *
 * This program is distributed in the hope that it will be useful,            *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.      *
 *                                                                            *
 * homepage: http://sourceforge.net/projects/nsnake/                          *
 *                                                                            *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

/**	@file	fruit.h
 * 	Declaration of the fruit functions, defines and globals
 *
 */

#ifndef FRUIT_DEFINED
#define FRUIT_DEFINED

/*------------------------------INCLUDES--------------------------------------*/


#include "nsnake.h"


/*------------------------------STRUCTURES------------------------------------*/

/**	The fruit structure
 *
 * 	Each fruit has it x and y positions
 * 	and a bonus score - indicating how many extra points
 * 	will be rewarded to the snake when it eats the fruit.
 */
typedef struct fruit_t
{
	int	x;		///< The x position of the fruit on stage
	int	y;		///< The y position of the fruit on stage
	int	bonus;		///< The bonus that the fruit adds to the score
	BOOLEAN	exists;		///< Flag to tell if there is a fruit on stage

} Fruit;

/*------------------------------GLOBALS---------------------------------------*/

extern Fruit fruit;	///< The fruit itself.

/*------------------------------FUNCTIONS-------------------------------------*/

void FRU_checkCollisionFruit ();
void FRU_createFruit ();
void FRU_updateFruitBonusValue ();

/*------------------------------END-------------------------------------------*/
#endif
