/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
 * nSnake - The classic snake game with ncurses.                              *
 * Copyright (C) 2011  Alexandre Dantas (kure)                                *
 *                                                                            *
 * This file is part of nSnake.                                               *
 *                                                                            *
 * nSnake is free software: you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation, either version 3 of the License, or          *
 * any later version.                                                         *
 *                                                                            *
 * This program is distributed in the hope that it will be useful,            *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.      *
 *                                                                            *
 * homepage: http://sourceforge.net/projects/nsnake/                          *
 *                                                                            *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

/**	@file   player.h
 *	Declaration of the player functions, defines and globals
 */

#ifndef PLAYER_DEFINED

/*------------------------------DEFINES---------------------------------------*/


#define PLAYER_DEFINED


/*------------------------------INCLUDES--------------------------------------*/


#include "nsnake.h"


/*------------------------------STRUCTURES------------------------------------*/


/**	The structure of each segmentation of the player.
 */
typedef struct snake_pieces_t
{
	int 	x;			///< The x position of this snake piece
	int 	y;			///< The y position of this snake piece

} SnakePieces;


/** A simple enum to make the directions of the player easier to read
 */
enum Directions { UP = 0, LEFT, DOWN, RIGHT };


/**	Represent the snake itself.
 */
typedef struct snake_t
{
	BOOLEAN 	is_alive;	///< Indicates if the player is alive

	int		speed;		///< How many chars will the player move by frame

	int		size;		///< The current size of the snake.pieces's body

	unsigned int	score;		///< The score :D

	enum Directions	direction;	///< Which direction shoud the player go

	SnakePieces*	body;		///< All pieces of the snake (including the head)

} Snake;


/*------------------------------GLOBALS---------------------------------------*/


extern Snake	snake;			///< The player himself


/*------------------------------FUNCTIONS-------------------------------------*/


void PLA_changePlayerDirection (enum Directions direction);
void PLA_checkCollisionSelf ();
void PLA_checkCollisionWall ();
void PLA_increasePlayerSize (int size);
void PLA_initPlayer ();
void PLA_normalCollisionWall ();
void PLA_teleportCollisionWall ();
void PLA_updatePlayer ();


/*------------------------------END-------------------------------------------*/
#endif

