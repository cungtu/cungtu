/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
 * nSnake - The classic snake game with ncurses.                              *
 * Copyright (C) 2011  Alexandre Dantas (kure)                                *
 *                                                                            *
 * This file is part of nSnake.                                               *
 *                                                                            *
 * nSnake is free software: you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation, either version 3 of the License, or          *
 * any later version.                                                         *
 *                                                                            *
 * This program is distributed in the hope that it will be useful,            *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.      *
 *                                                                            *
 * homepage: http://sourceforge.net/projects/nsnake/                          *
 *                                                                            *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

/**	@file   player.c
 *	Definition of the player functions
 */


/*------------------------------DEFINES---------------------------------------*/


#define PLAYER_C


/*------------------------------INCLUDES--------------------------------------*/


#include <stdlib.h>

#include "nsnake.h"
#include "engine.h"
#include "player.h"


/*------------------------------GLOBALS---------------------------------------*/


Snake	snake;


/*------------------------------FUNCTIONS-------------------------------------*/


/**	Changes the snake direction based on the input received
 */
void PLA_changePlayerDirection (enum Directions new_direction)
{
	     if ((new_direction == UP) && (snake.direction != DOWN) &&
	                                  (snake.direction != UP)        )
	{
		snake.direction = UP;
	}

	else if ((new_direction == LEFT) && (snake.direction != RIGHT) &&
	                                    (snake.direction != LEFT)    )
	{
		snake.direction = LEFT;
	}

	else if ((new_direction == DOWN) && (snake.direction != UP) &&
	                                    (snake.direction != DOWN)    )
	{
		snake.direction = DOWN;
	}

	else if ((new_direction == RIGHT) && (snake.direction != LEFT) &&
                                             (snake.direction != RIGHT)   )
	{
		snake.direction = RIGHT;
	}
}


/**	Checks if the snake have collided with itself
 */
void PLA_checkCollisionSelf ()
{
	int i;
	for (i = (snake.size-1); i > 1; i--)
	{
		if ((snake.body[0].x == snake.body[i].x) &&
		    (snake.body[0].y == snake.body[i].y))
		{
			snake.is_alive = False;
		}
	}
}


/**	Checks the collisions with the wall depending on the game mode
 */
void PLA_checkCollisionWall ()
{
	if (GAME_MODE == BORDERS_ON)
	{
		PLA_normalCollisionWall ();
	}
	else if (GAME_MODE == BORDERS_OFF)
	{
		PLA_teleportCollisionWall ();
	}
	else if (GAME_MODE == FREE_MODE)	//secret debugging-mode
	{}
}


/**	Increases the snake size.
 *
 * 	Here we have the core function of this file. Each time the snake
 * 	increases its size, we expand the array that represents its body.
 *
 * 	@note	This is the main function of this file, because it shows
 * 		how i've implemented the snake.
 */
void PLA_increasePlayerSize (int size)
{
	snake.size += size;

	snake.body = realloc (snake.body, (snake.size * sizeof (SnakePieces)));
	NSN_nullPointerCheck (snake.body);
}


/**	Starts the player-related variables
 */
void PLA_initPlayer ()
{
//general
	snake.is_alive	= True;
	snake.speed	= 1;
	snake.score	= 0;

	snake.direction = RIGHT;

//create
	snake.size = 3;

	if (snake.body != NULL)
	{
		free (snake.body);
		snake.body = NULL;
	}

	snake.body = malloc (snake.size * sizeof (SnakePieces));
	NSN_nullPointerCheck (snake.body);

//initialize
	int i;
	for (i = 0; i < snake.size; i++)
	{
		snake.body[i].x = WIDTH/2;
		snake.body[i].y = HEIGHT/2;
	}
}


/**	Checks collision between the snake and the walls
 *
 * 	@warning	Behind you!
 */
void PLA_normalCollisionWall ()
{
	if ((snake.body[0].x < 1) || (snake.body[0].x > (WIDTH-2)) ||
	    (snake.body[0].y < 2) || (snake.body[0].y > (HEIGHT-2)))
	{
		snake.is_alive = False;
	}
}


/**	Teleports the player around the borders
 */
void PLA_teleportCollisionWall ()
{
	if (snake.body[0].x < 1)
	{
		snake.body[0].x = WIDTH-2;
	}
	if (snake.body[0].y < 2)
	{
		snake.body[0].y = HEIGHT-2;
	}
	if (snake.body[0].x > (WIDTH-2))
	{
		snake.body[0].x = 1;
	}
	if (snake.body[0].y > (HEIGHT-2))
	{
		snake.body[0].y = 2;
	}
}


/**	Updates the player position, one piece at a time
 *
 *	Start by moving the snake pieces one at a time from the last to the
 *	first, and then moves the head according to its direction.
 */
void PLA_updatePlayer ()
{
// body
	int i;
	for (i = (snake.size-1); i > 0; i--)
	{
		snake.body[i].x = snake.body[i-1].x;
		snake.body[i].y = snake.body[i-1].y;
	}


// head
	     if (snake.direction == UP)
	{
		snake.body[0].y -= snake.speed;
	}
	else if (snake.direction == LEFT)
	{
		snake.body[0].x -= snake.speed;
	}
	else if (snake.direction == DOWN)
	{
		snake.body[0].y += snake.speed;
	}
	else if (snake.direction == RIGHT)
	{
		snake.body[0].x += snake.speed;
	}
}


/*------------------------------END-------------------------------------------*/

