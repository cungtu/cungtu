/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
 * nSnake - The classic snake game with ncurses.                              *
 * Copyright (C) 2011  Alexandre Dantas (kure)                                *
 *                                                                            *
 * This file is part of nSnake.                                               *
 *                                                                            *
 * nSnake is free software: you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation, either version 3 of the License, or          *
 * any later version.                                                         *
 *                                                                            *
 * This program is distributed in the hope that it will be useful,            *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.      *
 *                                                                            *
 * homepage: http://sourceforge.net/projects/nsnake/                          *
 *                                                                            *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

/**	@file	scores.h
 *	Declaration of the functions and structures related to scores.
 */

#ifndef SCORES_DEFINED


/*------------------------------DEFINES---------------------------------------*/


#define SCORES_DEFINED


/*------------------------------DEFINES---------------------------------------*/



extern unsigned int HIGH_SCORE_NORMAL;
extern unsigned int HIGH_SCORE_TELEPORT;


void SCO_increaseScore (int add);
void SCO_initHighScore ();
void SCO_obtainHighScore ();


/*------------------------------END-------------------------------------------*/
 #endif

