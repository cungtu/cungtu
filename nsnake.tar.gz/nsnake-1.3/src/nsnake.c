/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
 * nSnake - The classic snake game with ncurses.                              *
 * Copyright (C) 2011  Alexandre Dantas (kure)                                *
 *                                                                            *
 * This file is part of nSnake.                                               *
 *                                                                            *
 * nSnake is free software: you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation, either version 3 of the License, or          *
 * any later version.                                                         *
 *                                                                            *
 * This program is distributed in the hope that it will be useful,            *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.      *
 *                                                                            *
 * homepage: http://sourceforge.net/projects/nsnake/                          *
 *                                                                            *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

/**     @file   nsnake.c
 *
 *	This file contains the core functions of the game - except for the main.
 */

/*------------------------------DEFINES---------------------------------------*/


#define NSNAKE_C


/*------------------------------INCLUDES--------------------------------------*/


#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "nsnake.h"
#include "engine.h"
#include "fruit.h"
#include "player.h"
#include "scores.h"


/*------------------------------GLOBALS---------------------------------------*/


int GAME_MODE = BORDERS_ON;

short int GAME_LEVEL;


/*------------------------------FUNCTIONS-------------------------------------*/


/**	Aborts the game and displays the error message
 *
 * 	@note	EXIT_FAILURE is a portable constant for indicating
 * 		failure upon exiting a program.
 */
void NSN_abortGame (char* error_msg)
{
	ENG_exitGameEngine ();

	printf ("%s", error_msg);

	exit (EXIT_FAILURE);
}

/**	Checks if the pointer is null and aborts the game when necessairy.
 *
 * 	I made this function because of repetitive NULL-pointer checks
 * 	around malloc()s and realloc()s.
 */
void NSN_nullPointerCheck (void* pointer)
{
	if (pointer == NULL)
	{
		NSN_abortGame ("Memory Error!\n");
	}
}

/**	Interrupts the game and quits to the terminal.
 *
 * 	@note	EXIT_SUCCESS is a portable constant for indicating
 * 		success upon exiting a program.
 */
void NSN_exitGame ()
{
	if (snake.body != NULL)
	{
		free (snake.body);
		snake.body = NULL;
	}

	exit (EXIT_SUCCESS);
}


/**	Finish the game after the snake have lost a life.
 *
 * 	@see	ENG_drawGameOver()
 * 	@see	ENG_handleInputGameOver()
 */
void NSN_gameOver ()
{
	if (GAME_MODE == BORDERS_ON)
	{
		if (snake.score > HIGH_SCORE_NORMAL)
		{
			SCO_obtainHighScore ();
		}
	}
	else if (GAME_MODE == BORDERS_OFF)
	{
		if (snake.score > HIGH_SCORE_TELEPORT)
		{
			SCO_obtainHighScore ();
		}
	}

	ENG_drawGameOver ();
	ENG_handleInputGameOver ();

	NSN_initGame ();
}


/**	Deals with the command-line arguments.
 *
 *	It only supports --version and --help for now.
 *	TODO
 */
void NSN_handleArguments (int argc, char* argv[])
{
	if (argc > 1)
	{
		     if ((strcmp (argv[1], "--help") == 0) || (strcmp (argv[1], "-h") == 0))
		{
			NSN_printHelp ();
		}
		else if (strcmp (argv[1], "--version") == 0)
		{
			NSN_printVersion ();
		}
		else if ((strcmp (argv[1], "-gpl") == 0) || (strcmp (argv[1], "--license") == 0))
		{
			NSN_printLicense ();
		}
		else
		{
			NSN_printUsage ();
		}

		exit (EXIT_SUCCESS);
	}
}


/**	Starts al the necessairy stuff.
 *
 *	Sets all the global variables and call the initial functions so the
 *	game may start.
 *
 *  	@see	SCO_initHighScore()
 * 	@see	PLA_initPlayer()
 * 	@see	FRU_createFruit()
 * 	@see	ENG_drawScreenEngine()
 */
void NSN_initGame ()
{
	SCO_initHighScore ();
	PLA_initPlayer ();
	FRU_createFruit ();
	ENG_drawScreenEngine ();
}


/**	It, umm, pauses the game, i guess
 */
void NSN_pauseGame ()
{
	ENG_drawPause ();
	ENG_handleInputPauseMenu ();
}


/**	Prints Help instructions at standard input
 */
void NSN_printHelp ()
{
	printf("nSnake Help\n");
	printf("\n");
	printf("Sinopsys:\n");
	printf("\tThe classic snake game. You control a snake pursuing\n");
	printf("\tASCII-like fruits.\n");
	printf("\n");
	printf("Controls:\n");
	printf("\tNumbers (1~9)\t\tChanges the game speed at the main menu\n");
	printf("\tArrow Keys, WASD\tControl the snake directions\n");
	printf("\tq\t\t\tQuits the game at any time\n");
	printf("\tp\t\t\tPauses/Unpauses the game\n");
	printf("\n");
	printf("Commandline arguments:\n");
	printf("\t -h, \t--help\t\tDisplays this text\n");
	printf("\t\t--version\tDisplays the version and general informations\n");
	printf("\t-gpl,\t--license\tDisplays this program's license and warranty.\n");
	printf("\n");
	printf("Mailto:\t\talex.dantas92@gmail.com\n");
	printf("Homepage: \thttp://sourceforge.net/projects/nsnake\n");
	printf("\n");
}


/**	Prints the complete GNU GPL license v3
 */
void NSN_printLicense ()
{
	printf("nSnake - The classic snake game with ncurses.\n");
	printf("Copyright (C) 2011  Alexandre Dantas (kure)\n");
	printf("\n");
	printf("nSnake is free software: you can redistribute it and/or modify\n");
	printf("it under the terms of the GNU General Public License as published by\n");
	printf("the Free Software Foundation, either version 3 of the License, or\n");
	printf("any later version.\n");
	printf("\n");
	printf("This program is distributed in the hope that it will be useful,\n");
	printf("but WITHOUT ANY WARRANTY; without even the implied warranty of\n");
	printf("MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the\n");
	printf("GNU General Public License for more details.\n");
	printf("\n");
	printf("You should have received a copy of the GNU General Public License\n");
	printf("along with this program.  If not, see <http://www.gnu.org/licenses/>.\n");
	printf("\n");
}


/**	Prints the program usage at standard input
 */
void NSN_printUsage ()
{
	printf("Usage:\n");
	printf("\tnsnake [optional_arguments]\n");
	printf("\n");
	printf("Commandline arguments:\n\n");
	printf("\t -h, \t--help\t\tDisplays the help guidelines.\n");
	printf("\t\t--version\tDisplays the version and general informations\n");
	printf("\t-gpl,\t--license\tDisplays this program's license and warranty.\n");
	printf("\n");
}


/**	Prints the program version.
 */
void NSN_printVersion ()
{
	printf("nSnake v");
	printf(VERSION);
	printf("\t(");
	printf(DATE);
	printf(")\n");
	printf("Copyright (C) 2011  Alexandre Dantas (kure)\n");
	printf("\n");
	printf("This program comes with ABSOLUTELY NO WARRANTY; for details type --license.\n");
	printf("This is free software, and you are welcome to redistribute it\n");
	printf("under certain conditions; type --license for details.\n");
	printf("\n");
	printf("Mailto:\t\talex.dantas92@gmail.com\n");
	printf("Homepage: \thttp://sourceforge.net/projects/nsnake\n");
	printf("\n");
}

/*------------------------------END-------------------------------------------*/
