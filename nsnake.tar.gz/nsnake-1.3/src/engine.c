/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
 * nSnake - The classic snake game with ncurses.                              *
 * Copyright (C) 2011  Alexandre Dantas (kure)                                *
 *                                                                            *
 * This file is part of nSnake.                                               *
 *                                                                            *
 * nSnake is free software: you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation, either version 3 of the License, or          *
 * any later version.                                                         *
 *                                                                            *
 * This program is distributed in the hope that it will be useful,            *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.      *
 *                                                                            *
 * homepage: http://sourceforge.net/projects/nsnake/                          *
 *                                                                            *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

/**     @file   engine.c
 *	Definition of the graphical engine functions
 *
 *	This file presents the ncurses specifical implementation of the game`s
 * 	graphics.
 *
 */

/*------------------------------DEFINES---------------------------------------*/


#define ENGINE_C


/*------------------------------INCLUDES--------------------------------------*/


#include <stdio.h>
#include <stdlib.h>

#include <ncurses.h>	// the actual game engine

#include <unistd.h>	// for the usleep () function

#include "engine.h"
#include "fruit.h"
#include "player.h"
#include "scores.h"

/*------------------------------GLOBALS---------------------------------------*/

int WIDTH	= 80;
int HEIGHT	= 24;

double GAME_DELAY = 150000;		///< The game delay in microsseconds

static char PLAYER_CHAR	= 'o';		///< The char of the snake body
static char FRUIT_CHAR	= '$';		///< The char of the fruit
static char BORDER_CHAR	= '#';		///< The char of the border in normal mode
static char NO_BORDER_CHAR	= '.';	///< The char of the border in teleport mode


/// Simple enum to make the colors easier to read
enum Colors { SNAKE = 1, FRUIT, WALL, MESSAGE, MENU, OPTION, CUR_OPTION};

/*------------------------------FUNCTIONS-------------------------------------*/

/**	The logic process of displaying the main menu
 */
void ENG_displayMainMenu ()
{
	WINDOW*	main_menu;	// A window that will represent the main menu

	main_menu = ENG_initMainMenu ();
	ENG_drawMainMenu (main_menu);
	ENG_exitMainMenu (main_menu);
}


/**	Just erases everything to black
 */
void ENG_drawBackground ()
{
	clear();
}


/**	Draws the current fruit on screen
 */
void ENG_drawFruit ()
{
	attron (COLOR_PAIR(FRUIT));
	mvaddch (fruit.y, fruit.x, FRUIT_CHAR);
}


/**	Draws the bonus value of the current fruit
 */
void ENG_drawFruitBonus ()
{
	attron (COLOR_PAIR(WALL));
	mvprintw (0, (WIDTH-1)/2, "Bonus: %d", fruit.bonus);
}


/**	Draws the Game Over screen.
 *
 *	Besides drawing 'Game Over', it highlights where the player died.
 */
void ENG_drawGameOver ()
{
	attron (COLOR_PAIR (MESSAGE));

	mvaddch (snake.body[0].y, snake.body[0].x, 'x');

	mvprintw (3, 22, " _______  _______  __   __  _______ ");
	mvprintw (4, 22, "|       ||   _   ||  |_|  ||       |");
	mvprintw (5, 22, "|    ___||  |_|  ||       ||    ___|");
	mvprintw (6, 22, "|   | __ |       ||       ||   |___ ");
	mvprintw (7, 22, "|   ||  ||       ||       ||    ___|");
	mvprintw (8, 22, "|   |_| ||   _   || ||_|| ||   |___ ");
	mvprintw (9, 22, "|_______||__| |__||_|   |_||_______|");
	mvprintw (10, 22, " _______  __   __  _______  ______  ");
	mvprintw (11, 22, "|       ||  | |  ||       ||    _ | ");
	mvprintw (12, 22, "|   _   ||  |_|  ||    ___||   | || ");
	mvprintw (13, 22, "|  | |  ||       ||   |___ |   |_|| ");
	mvprintw (14, 22, "|  |_|  ||       ||    ___||    __ |");
	mvprintw (15, 22, "|       | |     | |   |___ |   |  ||");
	mvprintw (16, 22, "|_______|  |___|  |_______||___|  ||");

	mvprintw (17, 28, "Press <enter> to retry");
	mvprintw (18, 31, "<m> to Main Menu");
	ENG_drawScore ();

	refresh ();
}


/**	Prints on the screen the whole main menu and waits for user input
 */
void ENG_drawMainMenu (WINDOW* main_menu)
{
	bool wait = true;

	int speed_option = 1;
	char speed_options[9] = {'1', '2', '3', '4', '5', '6', '7', '8', '9'};


	int menu_x_padding = 13;
	int option_x_padding = menu_x_padding + 17;

	do {
		attron (COLOR_PAIR (SNAKE));
		mvprintw(1, 3,  "         ,d8888b.                     888");
		mvprintw(2, 3,  "        d88P  Y88b                    888");
		mvprintw(3, 3,  "         Y88b.                        888");
		mvprintw(4, 3,  "88888b.   Y888b.    88888b.    8888b. 888  888  .d88b.");
		mvprintw(5, 3,  "888  88b     8Y88b. 888  88b      88b 888 .88P d8P  Y8b");
		mvprintw(6, 3,  "888  888       888b 888  888 .d888888 888888K  88888888");
		mvprintw(7, 3,  "888  888 Y88b  d88P 888  888 888  888 888  88b Y8b.");
		mvprintw(8, 3,  "888  888   Y8888P   888  888  Y888888 888  888  Y88888");


		attron (COLOR_PAIR (FRUIT));
		mvaddch (8, 59, 'v');
		mvprintw (8, 60, VERSION);


		attron (COLOR_PAIR (MENU));
		mvprintw (10, 5, " ___________________________________________________ ");
		mvprintw (11, 5, "|                                                   |");
		mvprintw (12, 5, "|                                                   |");
		mvprintw (13, 5, "|                                                   |");
		mvprintw (14, 5, "|                                                   |");
		mvprintw (15, 5, "|                                                   |");
		mvprintw (16, 5, "|                                                   |");
		mvprintw (17, 5, "|                                                   |");
		mvprintw (18, 5, "|                                                   |");
		mvprintw (19, 5, "|___________________________________________________|");
		mvprintw (12, menu_x_padding, "Press <enter> or <space> to start game");
		mvprintw (13, menu_x_padding, "Press <q> to quit game");


		// Here we draw the game mode
		mvprintw (15, menu_x_padding, "Game Mode:");
		if (GAME_MODE == BORDERS_ON)
		{
			attron (COLOR_PAIR (CUR_OPTION));
			mvprintw (15, option_x_padding, "Borders On");

			attron (COLOR_PAIR (OPTION));
			mvprintw (16, option_x_padding, "Borders Off");
		}
		else
		{
			attron (COLOR_PAIR (OPTION));
			mvprintw (15, option_x_padding, "Borders On");

			attron (COLOR_PAIR (CUR_OPTION));
			mvprintw (16, option_x_padding, "Borders Off");
		}


		// And here we draw the level numbers
		attron (COLOR_PAIR (MENU));
		mvprintw (18, menu_x_padding, "Starting speed:");

		int i; int j;
		for (i = 0, j = 0; i < 9; i++)
		{
			if (i == (speed_option-1))
			{
				attron (COLOR_PAIR (CUR_OPTION));
			}
			else
			{
				attron (COLOR_PAIR (OPTION));
			}

			mvprintw (18, option_x_padding+j, "%c", speed_options [i]);
			j += 2;
		}


		attron (COLOR_PAIR (WALL));
		mvprintw (HEIGHT-2, 2, "Use --help for guidelines");


		// Now we wait for orders
		wait = ENG_handleInputMainMenu (&speed_option);


		// This function is so refreshing...
		wrefresh (main_menu);

	} while (wait == true);

	GAME_LEVEL = speed_option;
}


/**	Prints the pause message
 */
void ENG_drawPause ()
{
	attron (COLOR_PAIR (MESSAGE));

	mvprintw ((HEIGHT-1)/2, ((WIDTH-1)/2)-5, "Game Paused ");
	mvprintw (((HEIGHT-1)/2)+1, ((WIDTH-1)/2)-11, "Press <p> to Continue...");
}


/**	Draws the snake - from the head to the whole body
*/
void ENG_drawPlayer ()
{
	attron (COLOR_PAIR (SNAKE));

	mvaddch (snake.body[0].y, snake.body[0].x, '@');

	int i;
	for (i = 1; i < snake.size; i++)
	{
		mvaddch (snake.body[i].y, snake.body[i].x, PLAYER_CHAR);
	}
}


/**	Prints the current score
*/
void ENG_drawScore ()
{
	attron (COLOR_PAIR (FRUIT));
	mvprintw (0, 0, "nSnake v");
	mvprintw (0, 9, VERSION);

	attron (COLOR_PAIR (WALL));
	mvprintw (0, 17, "Lv%d", GAME_LEVEL);
	mvprintw (0, 23, "Score: %d", snake.score);

	     if (GAME_MODE == BORDERS_ON)
	{
		mvprintw (0, 60, "High Score: %d", HIGH_SCORE_NORMAL);
	}
	else if (GAME_MODE == BORDERS_OFF)
	{
		mvprintw (0, 60, "High Score: %d", HIGH_SCORE_TELEPORT);
	}
}


/**	Completely draws the screen during game.
 *
 * 	The usleep() function interrupts the program for 'n' microseconds.
 * 	It was difficult to get a stable value for the game progression.
 *
 *	@note	This is the main function of this file because it shows
 * 		logically how the process of drawing the screen sould be
 */
void ENG_drawScreenEngine ()
{
	ENG_drawBackground ();
	ENG_drawWindowBorder ();
	ENG_drawFruit ();
	ENG_drawPlayer ();
	ENG_drawFruitBonus();
	ENG_drawScore ();

	usleep ( 20000 + ((9 - GAME_LEVEL) * 25000));

	refresh();
}


/**	Draws the window border, according to the GAME_MODE.
 */
void ENG_drawWindowBorder ()
{
	int i;

	if (GAME_MODE == BORDERS_ON)
	{
		attron (COLOR_PAIR (WALL));
		for (i = 0; i <= (WIDTH-1); i++)	//upper
		{
			mvaddch (1, i, BORDER_CHAR);
			mvaddch ((HEIGHT-1), i, BORDER_CHAR);
		}
		for (i = 1; i <= (HEIGHT-1); i++)	//lower
		{
			mvaddch (i, 0, BORDER_CHAR);
			mvaddch (i, (WIDTH-1), BORDER_CHAR);
		}
	}
	else if (GAME_MODE == BORDERS_OFF)
	{
		attron (COLOR_PAIR (WALL));
		for (i = 0; i <= (WIDTH-1); i++)
		{
			mvaddch (1, i, NO_BORDER_CHAR);
			mvaddch ((HEIGHT-1), i, NO_BORDER_CHAR);
		}
		for (i = 1; i <= (HEIGHT-1); i++)
		{
			mvaddch (i, 0, NO_BORDER_CHAR);
			mvaddch (i, (WIDTH-1), NO_BORDER_CHAR);
		}
	}
}


/**	Exits and dealocates the memory required by ncurses
 */
void ENG_exitGameEngine ()
{
	clear ();
	refresh ();
	endwin ();
}


/**	Deletes the main menu from memory
 */
void ENG_exitMainMenu (WINDOW* main_menu)
{
	delwin (main_menu);
}



/**	Gets the input for the main menu
 */
bool ENG_handleInputMainMenu (int* speed_option)
{
	int input;
	input = getch();

	switch (input)
	{
		case ERR:		// if we get no input
			break;

		case '\n':	case ' ':
			return false;
			break;

		case 'q':	case 'Q':
			ENG_exitGameEngine();
			NSN_exitGame();
			break;

		case KEY_UP:
			if (GAME_MODE == BORDERS_OFF)
			{
				GAME_MODE = BORDERS_ON;
			}
			break;
		case KEY_DOWN:
			if (GAME_MODE == BORDERS_ON)
			{
				GAME_MODE = BORDERS_OFF;
			}
			break;

		case KEY_LEFT:
			if (*speed_option > 1)
			{
				(*speed_option)--;
			}
			break;

		case KEY_RIGHT:
			if (*speed_option < 9)
			{
				(*speed_option)++;
			}
			break;

		case '1':
			*speed_option = 1;
			break;
		case '2':
			*speed_option = 2;
			break;
		case '3':
			*speed_option = 3;
			break;
		case '4':
			*speed_option = 4;
			break;
		case '5':
			*speed_option = 5;
			break;
		case '6':
			*speed_option = 6;
			break;
		case '7':
			*speed_option = 7;
			break;
		case '8':
			*speed_option = 8;
			break;
		case '9':
			*speed_option = 9;
			break;

		default:
			break;
	}
	return true;
}


/**	Get the user input during game and make the right decisions
 */
void ENG_handleInputGame ()
{
	int input; //The input variable MUST be int to accept non-ascii characters

	input = getch ();

	switch (input)
	{
		case ERR:
			break;

		case KEY_UP:	case 'w':	case 'W':
			PLA_changePlayerDirection (UP);
			break;

		case KEY_LEFT:	case 'a':	case 'A':
			PLA_changePlayerDirection (LEFT);
			break;

		case KEY_DOWN:	case 's':	case 'S':
			PLA_changePlayerDirection (DOWN);
			break;

		case KEY_RIGHT:	case 'd':	case 'D':
			PLA_changePlayerDirection (RIGHT);
			break;

		case 'q':	case 'Q':
			ENG_exitGameEngine ();
			NSN_exitGame ();
			break;

#ifdef DEBUG
		case 'e':	case 'E':		//debug key TODO remove later
			SCO_increaseScore (100);
			PLA_increasePlayerSize (2);
			break;
#endif
		case 'p':	case 'P':
			NSN_pauseGame ();
			break;

		default:
			break;
	}
}


/**	Waits for an user action during the 'Game Over' screen
 */
void ENG_handleInputGameOver ()
{
	int input;
	bool wait = true;

	do {
		input = getch();

		switch (input)
		{
			case ERR:	// if we get no input
				break;

			case 'q':	case 'Q':
				ENG_exitGameEngine ();
				NSN_exitGame ();
				break;

			case 'm':	case 'M':
				wait = false;
				ENG_displayMainMenu ();

			case '\n':
				wait = false;
				break;

			default:
				break;
		}

	} while (wait == true);
}


/**	Just waits untill the user either unpauses the game or exits
 */
void ENG_handleInputPauseMenu ()
{
	int	input;
	bool	paused = true;

	curs_set (1);			// Makes the cursor visible again

	do
	{
		input = getch ();

		switch (input)
		{
			case 'p':	case 'P':
				paused = false;
				break;

			case 'q':	case 'Q':
				ENG_exitGameEngine ();
				NSN_exitGame ();
				break;

			default:
				break;
		}

	} while (paused == true);

	curs_set (0);			// And here it returns to be invisible
}


/**	Starts the game engine. Initializes all the stuff related to ncurses
 */
void ENG_initGameEngine ()
{
	initscr ();		// Starts the ncurses mode

	if (has_colors() == FALSE)
	{
		NSN_abortGame ("Your terminal does not support colors.\n");
	}

	start_color ();		// Start support for colors
	init_pair (SNAKE,	COLOR_GREEN,	COLOR_BLACK);
	init_pair (FRUIT,	COLOR_CYAN,	COLOR_BLACK);
	init_pair (WALL,	COLOR_WHITE,	COLOR_BLACK);
	init_pair (MESSAGE,	COLOR_RED,	COLOR_BLACK);
	init_pair (MENU,	COLOR_BLUE, 	COLOR_BLACK);
	init_pair (CUR_OPTION,	COLOR_WHITE, 	COLOR_BLACK);
	init_pair (OPTION,	COLOR_BLUE, 	COLOR_BLACK);

	attron (COLOR_PAIR (WALL));	// Starts with the wall color pair


	int current_height, current_width;

	getmaxyx (stdscr, current_height, current_width);

	if ((current_width < WIDTH) || (current_height < HEIGHT))
	{
		NSN_abortGame ("Your console screen is smaller than 80x24\nPlease resize your window and try again\n\n");
	}


	raw ();			// Character input doesnt require the <enter> key anymore

	curs_set (0);		// Makes the cursor invisible

	keypad (stdscr, true); 	// Support for extra keys (life F1, F2, ... )

	noecho ();		// Wont print the input received

	nodelay (stdscr, true);	// Wont wait for input - the game will run instantaneously

	refresh ();		// Refresh the screen (prints whats in the buffer)

	snake.body = NULL;
}


/**	Locally starts the main menu window and returns it
 */
WINDOW* ENG_initMainMenu ()
{
	WINDOW*	local_window;

	local_window = newwin (HEIGHT, WIDTH, 0, 0);

	box (local_window, '#', '#');
	mvwaddch (local_window, 0,       0,        '#');
	mvwaddch (local_window, HEIGHT-1, 0,       '#');
	mvwaddch (local_window, HEIGHT-1, WIDTH-1, '#');
	mvwaddch (local_window, 0,        WIDTH-1, '#');

	wrefresh (local_window);

	return local_window;
}


/*------------------------------END-------------------------------------------*/
