/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
 * nSnake - The classic snake game with ncurses.                              *
 * Copyright (C) 2011  Alexandre Dantas (kure)                                *
 *                                                                            *
 * This file is part of nSnake.                                               *
 *                                                                            *
 * nSnake is free software: you can redistribute it and/or modify             *
 * it under the terms of the GNU General Public License as published by       *
 * the Free Software Foundation, either version 3 of the License, or          *
 * any later version.                                                         *
 *                                                                            *
 * This program is distributed in the hope that it will be useful,            *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of             *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the              *
 * GNU General Public License for more details.                               *
 *                                                                            *
 * You should have received a copy of the GNU General Public License          *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.      *
 *                                                                            *
 * homepage: http://sourceforge.net/projects/nsnake/                          *
 *                                                                            *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

/**     @file   nsnake.h
 *
 *	This file defines the core functions, variables and structures.
 */

#ifndef NSNAKE_DEFINED


/*------------------------------DEFINES---------------------------------------*/


#define NSNAKE_DEFINED


/*------------------------------STRUCTURES------------------------------------*/


/**	Custom implementation of the Boolean type
 *
 *	Explanation:	The C Language doesn't have the Boolean type by default. @n
 *			A Boolean variable can only be true or false. @n
 *			This type is useful for logical comparisons such as
 *			"The snake is alive? True!" or "The game is paused? False!"
 */
typedef enum {
	False   = 0,
	True    = 1
} BOOLEAN;


/*------------------------------GLOBALS---------------------------------------*/


/** The collision mode of the game.
 *
 *  It starts with BORDERS_ON, but can be changed at the main menu.
 */
extern int GAME_MODE;

/** The possible Game Modes.
 *
 *  In Normal Mode, the snake dies by colliding with itself or the borders. @n
 *  In Teleport Mode, the snake only dies by colliding with itself. @n
 *  @note	Free Mode is for testing purposes only.
 */
enum GameModes { FREE_MODE, BORDERS_ON, BORDERS_OFF };

/** The GAME_LEVEL represents the game speed. The bigger it is, the faster
 *  the snake will move.
 */
extern short int GAME_LEVEL;


/*------------------------------FUNCTIONS-------------------------------------*/


void NSN_abortGame (char* error_msg);
void NSN_nullPointerCheck (void* pointer);
void NSN_exitGame ();
void NSN_gameOver ();
void NSN_handleArguments (int argc, char* argv[]);
void NSN_initGame ();
void NSN_pauseGame ();
void NSN_printHelp ();
void NSN_printLicense ();
void NSN_printUsage ();
void NSN_printVersion ();


/*------------------------------END-------------------------------------------*/
#endif

